public enum Sym {
    LCHEVRON,
    RCHEVRON,
    MOT,
    SLASH,
    EQ,
    STRING,
    PROLOGUE,
    EOF;  //token representinting the end of file
}
