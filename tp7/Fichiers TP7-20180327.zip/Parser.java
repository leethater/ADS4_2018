import java.io.*;
import java.util.*;

class Parser {
	/*
	 * grammaire equivalente LL1 
	 * S -> prologue < A $
	 * A -> mot Atr ASuite
	 * Atr -> epsilon | mot = string Atr
	 * ASuite -> /> | > < E
	 * E -> / mot > | A < E
	 */
    protected LookAhead1 reader;

    public Parser(LookAhead1 r) {
	reader=r;
    }

   
    // Completez ici
    public Arbre nonterm_S() throws Exception {
    }

    public Arbre nonterm_A() throws Exception {
    }
    
    public Map<String,String> nonterm_Atr() throws Exception {
    }
    
    public List<Arbre> nonterm_ASuite() throws Exception {	
    }
    
    
    public List<Arbre> nonterm_E() throws Exception {
    }
}
